﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $rootnamespace$.Controllers
{
    /// <summary>
    /// Cette interface définit l'ensemble des méthodes définissant un Controler $fileinputname$
    /// </summary>
    public interface I$fileinputname$Controller
    {
        #region Run Method

        /// <summary>
        /// Méthode permettant l'exécution du Controller
        /// </summary>
        void Run();

        #endregion
    }
}
