﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Composite.Regions;
using $rootnamespace$.Controllers;
using $rootnamespace$.Services;

namespace $rootnamespace$
{
    /// <summary>
    /// Cette classe représente un Module $fileinputname$
    /// </summary>
    public class $fileinputname$Module : IModule
    {
        #region Private Members

        /// <summary>
        /// Container Unity pour instanciation des type d'objet
        /// </summary>
        private readonly IUnityContainer container;

        /// <summary>
        /// Registre des vues à afficher
        /// </summary>
        private readonly IRegionViewRegistry regionViewRegistry;

        /// <summary>
        /// Manager de Region d'affichage
        /// </summary>
        private readonly IRegionManager regionManager;

        #endregion
                
        #region Constructor

        /// <summary>
        /// Constructeur par défaut
        /// </summary>
        /// <param name="container">Container Unity pour instanciation des type d'objet</param>
        /// <param name="regionViewRegistry">Registre des vues à afficher</param>
        /// <param name="regionManager">Manager de Region d'affichage</param>
        public $fileinputname$Module(IUnityContainer container, IRegionViewRegistry regionViewRegistry, IRegionManager regionManager)
        {
            this.container = container;
            this.regionViewRegistry = regionViewRegistry;
            this.regionManager = regionManager;
        }

        #endregion

        #region Initialize Method

        /// <summary>
        /// Intialisation du module principal
        /// </summary>
        public void Initialize()
        {
            this.RegisterTypesAndServices();

            this.InitializeController();
        }

        #endregion

        #region InitializeController Method

        /// <summary>
        /// Enregistrement des vues dans les regions d'affichage
        /// </summary>
        private void InitializeController()
        {
            I$fileinputname$Controller controller = container.Resolve<I$fileinputname$Controller>();
            this.container.RegisterInstance<I$fileinputname$Controller>(controller);

            controller.Run();
        }

        #endregion

        #region RegisterTypesAndServices Method

        /// <summary>
        /// Enregistrement des type et des services
        /// </summary>
        private void RegisterTypesAndServices()
        {
            this.container.RegisterType<I$fileinputname$Controller, $fileinputname$Controller>(new ContainerControlledLifetimeManager());
            this.container.RegisterType<I$fileinputname$Service, $fileinputname$Service>();
        }

        #endregion
    }
}
