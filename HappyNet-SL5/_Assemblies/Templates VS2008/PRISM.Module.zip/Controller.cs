﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Composite.Regions;
using Microsoft.Practices.Composite.Events;

namespace $rootnamespace$.Controllers
{
    /// <summary>
    /// Cette classe représente un Controler $fileinputname$
    /// </summary>
    public class $fileinputname$Controller : I$fileinputname$Controller
    {
        #region EventAggregator Property

        /// <summary>
        /// Gestionnaire d'Evènement
        /// </summary>
        public IEventAggregator EventAggregator { get; protected set; }

        #endregion

        #region RegionManager Property

        /// <summary>
        /// Manager de Region d'affichage
        /// </summary>
        public IRegionManager RegionManager { get; protected set; }

        #endregion

        #region RegionViewRegistry Property

        /// <summary>
        /// Registre des vues à afficher
        /// </summary>
        public IRegionViewRegistry RegionViewRegistry { get; protected set; }

        #endregion

        #region Container Property

        /// <summary>
        /// Container d'intanciation Unity
        /// </summary>
        public IUnityContainer Container { get; protected set; }

        #endregion
        
        #region Constructor

        /// <summary>
        /// Constructeur par défaut avec le manager de regions, le container Unity, l'enregistreur de vues et le gestionnaire des Evènements
        /// </summary>
        /// <param name="regionManager">manager de regions</param>
        /// <param name="container">container Unity</param>
        /// <param name="regionViewRegistry">enregistreur de vues</param>
        /// <param name="eventAggregator">gestionnaire des Evènements</param>
        public $fileinputname$Controller(IRegionManager regionManager, IUnityContainer container, IRegionViewRegistry regionViewRegistry, IEventAggregator eventAggregator)
        {
            this.EventAggregator = eventAggregator;
            this.RegionManager = regionManager;
            this.RegionViewRegistry = regionViewRegistry;
            this.Container = container;
        }

        #endregion
        
        #region Run Method

        /// <summary>
        /// Méthode permettant l'exécution du Controller
        /// </summary>
        public void Run()

        {
        }

        #endregion
    }
}
