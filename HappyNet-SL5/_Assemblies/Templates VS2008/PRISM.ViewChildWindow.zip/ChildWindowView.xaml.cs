﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $rootnamespace$
{
    /// <summary>
    /// Cette classe représente l'affichage du $fileinputname$
    /// </summary>
    public partial class $fileinputname$ChildWindowView : ChildWindow, I$fileinputname$ChildWindowView
    {
        #region Model property

        /// <summary>
        /// Model presentation attaché à la vue
        /// </summary>
        /// 
        public I$fileinputname$ChildWindowViewModel Model
        {
            get { return this.DataContext as I$fileinputname$ChildWindowViewModel; }
            set { this.DataContext = value; }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructeur par défaut
        /// </summary>
        public $fileinputname$ChildWindowView()
        {
            InitializeComponent();
        } 

        #endregion

    }
}
