﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace $rootnamespace$
{
    /// <summary>
    /// Cette interface définit le Vue Model (PresentationModel) pour le $fileinputname$
    /// </summary>
    public interface I$fileinputname$ChildWindowViewModel
    {
        #region View Property

        /// <summary>
        /// Vue à utliser 
        /// </summary>
        I$fileinputname$ChildWindowView View { get; }

        #endregion

         /// <summary>
        /// Commande permettant l'annulation
        /// </summary>
        ICommand CancelCommand { get; }

        /// <summary>
        /// Commande permettant la validation
        /// </summary>
        ICommand ValidateCommand { get;}
    }
}
