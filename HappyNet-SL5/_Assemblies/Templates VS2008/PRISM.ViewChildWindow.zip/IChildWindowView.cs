﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $rootnamespace$
{
    /// <summary>
    /// Cette interface définit la Vue pour le $fileinputname$
    /// </summary>
    public interface I$fileinputname$ChildWindowView
    {
        #region Model property

        /// <summary>
        /// Model presentation attaché à la vue
        /// </summary>
        I$fileinputname$ChildWindowViewModel Model { get; set; }

        #endregion
    }
}
