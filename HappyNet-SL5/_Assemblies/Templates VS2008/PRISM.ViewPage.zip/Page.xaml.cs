﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Navigation;

namespace $rootnamespace$
{
    /// <summary>
    /// Cette classe représente l'affichage d'une Page $fileinputname$
    /// </summary>
    public partial class $fileinputname$Page : Page
    {
        #region Constructor

        /// <summary>
        /// Constructeur par défaut
        /// </summary>
        public $fileinputname$Page()
        {
            InitializeComponent();
        }

        #endregion

        /// </summary>
        /// Executes when the user navigates to this page.
        /// </summary>
        /// <param name="e">Navigation EventArgs</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            
        }
    }
}
