﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel;
using Microsoft.Practices.Composite.Events;
using Microsoft.Practices.Composite.Modularity;
using Microsoft.Practices.Composite.Presentation.Commands;

namespace $rootnamespace$.$fileinputname$
{
    /// <summary>
    /// Cette classe représente le Vue Model (PresentationModel) pour le $fileinputname$
    /// </summary>
    public class $fileinputname$ViewPresentationModel : INotifyPropertyChanged, I$fileinputname$ViewPresentationModel
    {
        #region INotifyPropertyChanged Members

        /// <summary>
        /// Evènement lorsque qu'une propriété du ModelView est changée
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Evènement lorsque qu'une propriété du ModelView est changée
        /// </summary>
        protected void OnPropertyChanged(string propertyName)
        {
            if (this.PropertyChanged != null)
            {
                this.PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        #endregion

        #region EventAggregator Property

        /// <summary>
        /// Gestionnaire d'Evènement
        /// </summary>
        public IEventAggregator EventAggregator { get; private set; }

        #endregion

        #region View Property

        /// <summary>
        /// Vue à utliser 
        /// </summary>
        public I$fileinputname$View View { get; private set; }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructeur par défaut
        /// </summary>
        /// <param name="view">Vue sur laquelle est implémentée le ViewModel</param>
        /// <param name="eventAggregator">Gestionnaire d'Evènements</param>
        public $fileinputname$ViewPresentationModel(I$fileinputname$View view, IEventAggregator eventAggregator)
        {
            this.InitializeCommands();

            this.EventAggregator = eventAggregator;
            this.View = view;
            this.View.Model = this;
        } 

        #endregion

        #region InitializeCommands Method

        /// <summary>
        /// Cette méthode permet l'initialisation des es
        /// </summary>
        public void InitializeCommands()
        {
            
        } 

        #endregion
    }
}
