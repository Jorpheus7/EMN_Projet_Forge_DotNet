﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace $rootnamespace$.$fileinputname$
{
    /// <summary>
    /// Cette classe représente l'affichage du $fileinputname$
    /// </summary>
    public partial class $fileinputname$View : UserControl, I$fileinputname$View
    {
        #region Model property

        /// <summary>
        /// Model presentation attaché à la vue
        /// </summary>
        public I$fileinputname$ViewPresentationModel Model
        {
            get { return this.DataContext as I$fileinputname$ViewPresentationModel; }
            set { this.DataContext = value; }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Constructeur par défaut
        /// </summary>
        public $fileinputname$View()
        {
            InitializeComponent();
        } 

        #endregion
    }
}
